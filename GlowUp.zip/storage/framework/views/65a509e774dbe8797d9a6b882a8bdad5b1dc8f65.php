<script src="https://cdnjs.cloudflare.com/ajax/libs/flowbite/1.8.1/flowbite.min.js"></script>

</body>
</html><?php /**PATH D:\Wampp\www\GlowUp\resources\views/layouts/footer.blade.php ENDPATH**/ ?>